﻿var http = require('http');

http.createServer(function (request, response,next) {

	// 发送 HTTP 头部 
	// HTTP 状态值: 200 : OK
	// 内容类型: text/plain
	//response.writeHead(200, {'Content-Type': 'text/plain'});
	response.writeHead("200", { "Content-Type": "text/plain" });

	// 发送响应数据 "Hello World"
	var data = "{rs:\"Y\"}";
	response.write("jsonpCallback("+data+")");
	response.end();
	test();
}).listen(22222);

// 终端打印如下信息
console.log('开始监听拍照/');


function test(){
//var iconv = require('iconv-lite');

var path = require("path");  
//根目录，如app://movie_desktop  
//var rootArray = window.document.location.href.split("/");  
//var rootPath = rootArray[0] + "//" + rootArray[2];  
//数据存储地址  
//var dataPath = require('nw.gui').App.dataPath;  
//nw.exe运行地址  
var execPath = path.dirname(process.execPath);  
//应用地址  
var cwdPath = process.cwd();  
//console.log("rootArray:"+rootArray +",rootPath:"+rootPath +",dataPath:"+dataPath +",execPath:"+execPath+",cwdPath:"+cwdPath);
const exec = require('child_process').exec;//产生exec，同时传入.bat文件
cwdPath = cwdPath.replace("/","\\");
exec(cwdPath  + '\\take_photo_model\\OperateCamera.exe', (err, stdout, stderr) => {
  if (stderr) {

    

  console.log(err.message);

  }
	
	if(stdout){
		var obj = JSON.parse(stdout);
		if(obj.result=='Y'){
				alert("拍照成功");
				
				
				
		}else{
			console.log(obj);
		}
	}	
  console.log(stdout);
});


}
	
	


  
